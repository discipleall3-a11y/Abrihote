# Abrihote Kristos — Installable Offline App

This folder turns the devotional study app into a real installable app for
Android, iOS, and Windows, with full offline reading and reflection.

## What changed from the Claude.ai version

- **Storage**: the app now saves data with the browser's own IndexedDB
  instead of Claude's `window.storage`. That's what lets it run completely
  on its own, with no Claude.ai connection needed at all.
- **PWA files**: `manifest.json` (app name/icon/colors) and `sw.js` (a
  service worker that caches the app so it loads with zero internet).
- **Icons**: `icons/` — generated to match the app's logo.

## ⚠️ Please read: what "offline" means here

This app has **no server**. That keeps it simple and free to run, but it
means:

- ✅ **Fully offline, on every platform**: reading both Bibles, the annual
  reading plan with progress tracking, your profile, font-size
  preferences — all of this lives on each person's own device and needs
  no internet at all, ever, after the first install.
- ⚠️ **Devotionals, prayer requests, comments, and membership
  approval are local to each device.** If your leader posts a devotional
  on their phone, it will **not** automatically appear on a member's
  phone — there's no shared server to sync it. Each installed copy of the
  app is its own island.

  For a small group meeting in person, a simple workaround is for the
  leader to read/share devotionals out loud or via a message app, while
  everyone still uses this app for their own personal Bible reading and
  reading-plan tracking, which works great offline as-is.

  If you want devotionals/prayers/approvals to genuinely sync across
  everyone's phones, that requires adding a real backend (for example
  Firebase or Supabase, both have free tiers). I can build that next if
  you'd like — just ask, and let me know if you'd rather use Firebase,
  Supabase, or something else.

## How to install it

A PWA must be served over **HTTPS** (or accessed at `localhost`) for the
"Install app" / "Add to Home Screen" options and offline caching to work.
Opening `index.html` directly by double-clicking it will NOT enable
installation or offline mode — you need to host the folder somewhere
first. The free options below take a few minutes.

### 1. Host the folder (pick one, all free)

- **Netlify Drop** — go to https://app.netlify.com/drop and drag this
  whole folder onto the page. You'll get a live HTTPS link instantly.
- **GitHub Pages** — create a new GitHub repo, upload these files, then
  enable Pages in the repo's Settings (Settings → Pages → deploy from the
  `main` branch).
- **Vercel** — https://vercel.com → "Add New Project" → upload the folder.

Any of these gives you a URL like `https://your-app.netlify.app`.

### 2. Install on Android

1. Open the link in **Chrome**.
2. Tap the **⋮ menu → "Install app"** (or you'll see an automatic install
   banner).
3. It now appears on the home screen and app drawer like a normal app,
   and opens full-screen with no browser bar.

### 3. Install on iOS (iPhone/iPad)

1. Open the link in **Safari** (must be Safari, not Chrome, for this to
   work on iOS).
2. Tap the **Share button** → **"Add to Home Screen"**.
3. It now appears as an icon on the home screen and opens full-screen.

   Note: iOS Safari supports offline caching and home-screen install, but
   Apple limits some background PWA features compared to Android — this
   app doesn't need those, so you're fine.

### 4. Install on Windows

1. Open the link in **Edge** or **Chrome**.
2. Click the **install icon (⊕)** in the address bar, or **⋮ menu →
   "Apps" → "Install this site as an app."**
3. It's added to the Start Menu and Taskbar, and opens in its own window.

## Updating the app later

If you (or I) make changes to `index.html`, bump the version string in
`sw.js` (`CACHE_NAME = "abrihote-kristos-v2"`, etc.) and re-upload — this
tells installed copies to fetch the new version instead of the old
cached one.
